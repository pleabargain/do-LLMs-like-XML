import { N, _ } from "../chunks/2.Dc6zh421.js";
export {
  N as component,
  _ as universal
};
